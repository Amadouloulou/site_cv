	    </div>
	    <!-- end .main -->

    </div>
    <!-- end #main-container -->

    <!-- begin footer-container -->
    <div class="footer-container">
		<footer class="footer grid">

			<!-- begin copyright -->
			<?php echo of_get_option('footer_copyright')  ?>
			<!-- end copyright -->

			<!-- Site5 Credits-->
			<br>Created by <a href="http://www.s5themes.com/">Site5 WordPress Themes</a>. Experts in <a href="http://gk.site5.com/t/705">WordPress Hosting</a>
			<!-- end Site5 Credits-->
		</footer>
    </div>
    <!-- end footer-container -->

<?php wp_footer(); ?>

	</body>
</html>