<?php get_header(); ?>


	<section class="page-content primary unit" role="main">

		<h1><?php _e('404 Not Found','site5framework') ?></h1>

		<?php _e("The article you were looking for was not found, but maybe try looking again!", "site5framework"); ?>

	</section>


<?php get_footer(); ?>